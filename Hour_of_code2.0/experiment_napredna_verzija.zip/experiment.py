import random
import sys
import threading
import serial.tools.list_ports
import time
import csv
from itertools import zip_longest
import pyqtgraph as pg
from PyQt5 import QtGui, QtCore, uic

plot_data_nr=200
y_max=6
y_min=0


class MainWindow(QtGui.QMainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__()

        #load gui from .ui file
        uic.loadUi('experiment.ui', self)

        #flag for connection checking -> enables disconnection with the same button
        self.connected=False
        # callback functions for buttons
        self.btn_quit.clicked.connect(self.closeIt)
        self.btn_connect.clicked.connect(self.plotter)
        self.btn_save.clicked.connect(self.save_data)
        #PADAJUCI IZBORNIK
        self.serial_ports = self.serial_ports()
        self.comboBox.addItems([i.description for i in self.serial_ports])

        # Setiranje osi grafa
        self.graphicsView.setYRange(y_min,y_max)

    def serial_ports(self):
        return serial.tools.list_ports.comports()

    def plotter(self):
        if(self.connected==False):
            try:
                port=self.serial_ports[self.comboBox.currentIndex()].device
                self.serial_port=serial.Serial(port,115200)  # zasad je baudrate zaharkodiran
                self.connected=True
                self.btn_connect.setText("Disconnect")
                self.stop_thread = False
                self.thread=threading.Thread(target=self.updater)
                self.thread.start()
            except:
                QtGui.QMessageBox.warning(self, "Application", "No device found on serial port!")
                return
        else:
            self.stop_thread=True
            #wait for the thread to finish, otherwise error will occur
            while self.stop_thread:
                pass
            self.serial_port.close()
            self.connected=False
            self.btn_connect.setText("Connect")


    def updater(self):
        self.data = []
        self.time = []
        self.t0 = time.time()

        #set graph to initial state
        self.graphicsView.clear()
        self.curve = self.graphicsView.getPlotItem().plot()
        #MOŽDA nam ne treba ova linija, odnosno treba drugačije postupiti
        self.serial_port.flushInput()

        while not self.stop_thread:
            # self.serial_port.reset_input_buffer()
            data = self.serial_port.readline().decode().split('\r\n')
            #print(data[0])
            self.data.append(float(data[0])*5.0/1024)
            self.time.append(time.time()-self.t0)
            if len(self.data) > plot_data_nr:
                self.data.pop(0)
                self.time.pop(0)
            self.curve.setData(self.time,self.data)
            self.curve.update()
        self.stop_thread=False

    def save_data(self):
        # check if there is any data recorded
        try:
            filename = QtGui.QFileDialog.getSaveFileName(self, 'Save File', '.csv')
            with open(filename[0], 'w',newline='') as csv_file:
                wr = csv.DictWriter(csv_file, fieldnames=["Data", "Time"])
                wr.writeheader()
                date_time = zip_longest(self.data,self.time)
                wr.writerows({'Data':row[0], 'Time':row[1]} for row in date_time)

        except:
            pass

    def closeIt(self):
        if self.connected==True:
            self.plotter()
        exit(0)

if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec_())