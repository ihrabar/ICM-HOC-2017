import sys
import pyqtgraph as pg
import serial
from PyQt5 import QtGui, QtCore, uic


ser=serial.Serial("COM6",115200)
class MainWindow(QtGui.QMainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__()

        #load gui from .ui file
        uic.loadUi('led.ui', self)

        self.btn_led.clicked.connect(self.send_value)

    def send_value(self):
        print(self.sld_led.sliderPosition())
        ser.write(bytes([self.sld_led.sliderPosition()]))

if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec_())